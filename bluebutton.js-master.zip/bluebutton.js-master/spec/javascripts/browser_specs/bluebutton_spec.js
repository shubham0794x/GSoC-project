describe("BlueButton", function() {
  
  it("should be defined on window", function() {
    expect(window.BlueButton).toBeDefined();
  });

  runDateParsingTests(Documents);
  
});